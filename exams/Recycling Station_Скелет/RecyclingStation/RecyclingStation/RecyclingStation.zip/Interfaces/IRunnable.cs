﻿namespace RecyclingStation.Interfaces
{
    public interface IRunnable
    {
        void Run();
    }
}
