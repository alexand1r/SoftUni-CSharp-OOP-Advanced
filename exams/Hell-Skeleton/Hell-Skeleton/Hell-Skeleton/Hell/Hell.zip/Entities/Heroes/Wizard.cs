﻿public class Wizard : Hero
{
    public Wizard(string name) 
        : base(name, 25, 25, 100, 100, 250)
    {
    }
}
