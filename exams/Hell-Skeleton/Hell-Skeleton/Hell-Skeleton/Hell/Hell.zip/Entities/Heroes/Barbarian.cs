﻿public class Barbarian : Hero
{
    public Barbarian(string name) 
        : base(name, 90, 25, 10, 350, 100)
    {
    }
}
