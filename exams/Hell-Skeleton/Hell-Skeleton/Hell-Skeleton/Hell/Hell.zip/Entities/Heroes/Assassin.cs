﻿public class Assassin : Hero
{
    public Assassin(string name) 
        : base(name, 25, 100, 15, 150, 300)
    {
    }
}
