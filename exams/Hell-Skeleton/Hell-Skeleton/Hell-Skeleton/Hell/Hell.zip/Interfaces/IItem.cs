﻿public interface IItem
{
    string Name { get; }

	int StrengthBonus { get; }

    int AgilityBonus { get; }

	int IntelligenceBonus { get; }

	int HitPointsBonus { get; }

	int DamageBonus { get; }


}
