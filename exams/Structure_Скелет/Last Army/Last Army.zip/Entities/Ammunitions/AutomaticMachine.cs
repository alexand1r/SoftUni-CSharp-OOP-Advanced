﻿public class AutomaticMachine : Ammunition
{
    public const double BaseWeight = 6.3;

    public AutomaticMachine(string name)
        : base(name, BaseWeight)
    {
    }
}