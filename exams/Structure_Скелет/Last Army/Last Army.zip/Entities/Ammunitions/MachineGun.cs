﻿
    public class MachineGun : Ammunition
    {
        public const double BaseWeight = 10.6;

        public MachineGun(string name)
            : base(name, BaseWeight)
        {
        }
    }
