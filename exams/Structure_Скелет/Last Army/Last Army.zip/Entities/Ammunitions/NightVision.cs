﻿
    public class NightVision : Ammunition
    {
        public const double BaseWeight = 0.8;

        public NightVision(string name)
            : base (name, BaseWeight)
        {
        }
    }
