﻿
    public class Knife : Ammunition
    {
        public const double BaseWeight = 0.4;

        public Knife(string name)
            : base (name, BaseWeight)
        {
        }
    }
