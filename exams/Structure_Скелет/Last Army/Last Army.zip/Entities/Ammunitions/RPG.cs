﻿
    public class RPG : Ammunition
    {
        public const double BaseWeight = 17.1;

        public RPG(string name)
            : base(name, BaseWeight)
        {
        }
    }
