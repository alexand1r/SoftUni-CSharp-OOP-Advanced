﻿public class OutputMessages
{
    public const string MissionDeclined = "{}";
    public const string MissionSuccessful = "{}";
    public const string MissionOnHold = "{}";
    public const string SoldierToString = "{}";
}
