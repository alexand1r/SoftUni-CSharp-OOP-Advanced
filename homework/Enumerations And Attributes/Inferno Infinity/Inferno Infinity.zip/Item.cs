﻿abstract class Item
{
    internal enum ItemRarity
    {
        Common, Uncommon, Rare, Epic
    }
}