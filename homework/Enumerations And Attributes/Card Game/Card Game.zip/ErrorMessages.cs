﻿static class ErrorMessages
{
    public static string InvalidCard => "No such card exists.";
    public static string CardAlreadyDistribted => "Card is not in the deck.";
}