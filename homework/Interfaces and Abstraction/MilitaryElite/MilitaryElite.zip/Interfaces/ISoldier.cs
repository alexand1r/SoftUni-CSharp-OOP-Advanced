﻿public interface ISoldier
{
    string ID { get; }

    string Firstname { get; }

    string LastName { get; }

}