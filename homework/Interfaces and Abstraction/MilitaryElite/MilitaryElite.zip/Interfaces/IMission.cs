﻿public interface IMission
{
    string Name { get; }

    string State { get; }
}