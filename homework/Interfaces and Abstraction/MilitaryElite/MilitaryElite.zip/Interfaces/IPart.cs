﻿public interface IPart
{
    string PartName { get; }

    int WorkedHours { get; }
}