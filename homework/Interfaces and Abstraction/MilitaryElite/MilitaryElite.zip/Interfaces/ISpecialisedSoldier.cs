﻿public interface ISpecialisedSoldier : IPrivate
{
    string Corpus { get; set; }
}