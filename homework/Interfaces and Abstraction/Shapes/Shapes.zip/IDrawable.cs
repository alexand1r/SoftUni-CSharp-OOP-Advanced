﻿interface IDrawable
{
    void Draw();
}