﻿public interface ICar
{
    string Driver { get; }

    string Brakes();

    string Gas();
}