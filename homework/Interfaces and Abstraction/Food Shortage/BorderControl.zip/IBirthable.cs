﻿public interface IBirthable
{
    string Birthdate { get; }

    void CheckBirthdate(string pattern);

}