﻿public interface IPresident
{
    string Name { get; set; }

    string Country { get; set; }

    string GetName();
}