﻿interface IElectricCar
{
    int Battery { get; }
}