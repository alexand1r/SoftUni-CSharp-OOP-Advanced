﻿public interface ICaller
{
    void Call();
}