﻿public interface IBrowser
{
    void Browse();
}