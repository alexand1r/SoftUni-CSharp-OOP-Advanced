﻿public interface IAddable
{

    int Add(string item);
}