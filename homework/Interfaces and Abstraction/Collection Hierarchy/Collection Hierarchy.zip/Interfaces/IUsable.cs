﻿public interface IUsable : IRemovable
{
    int Count();
}