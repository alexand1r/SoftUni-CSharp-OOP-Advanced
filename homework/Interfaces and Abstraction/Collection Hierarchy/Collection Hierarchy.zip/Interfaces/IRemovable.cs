﻿public interface IRemovable : IAddable
{
    string Remove();
}