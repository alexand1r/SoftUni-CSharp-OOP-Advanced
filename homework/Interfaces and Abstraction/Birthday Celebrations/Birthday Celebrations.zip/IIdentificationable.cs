﻿public interface IIdentificationable
{
    string Name { get; }
    string Birthday { get; }
}