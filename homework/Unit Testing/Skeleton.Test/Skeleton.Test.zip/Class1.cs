﻿using System;
using NUnit.Framework;

[TestFixture]
public class Class1
{
    [Test]
    public void AxeLosesDurabilyAfterAttack()
    {
        // Arrange
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(10, 10);

        // Act
        axe.Attack(dummy);

        // Assert
        Assert.AreEqual(9, axe.DurabilityPoints, "Axe Durabolity doesn't change after attack");
    }

    [Test]
    public void BrokenAxeCantAttack()
    {
        Axe axe = new Axe(1, 1);
        Dummy dummy = new Dummy(10, 10);

        axe.Attack(dummy);

        var ex = Assert.Throws<InvalidOperationException>
            (() => axe.Attack(dummy));
        Assert.That(ex.Message, Is.EqualTo("Axe is broken."));
    }
}
